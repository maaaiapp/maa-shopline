"""HTTP API for the iOS client.

Tenant identity: an HMAC-signed session issued only at OAuth completion and bound
to shop_id. No endpoint accepts a shop id from the client. Errors are mapped to UI
states (loading/empty/unavailable/degraded/queued/insufficient); raw exceptions
and provider messages are never returned.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from datetime import date

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse

from app.config import Settings, assert_isolated
from app.inference.gateway import Gateway, Policy
from app.inference.providers import OpenAICompatAdapter
from app.inference.registry import DataClass
from app.inference.validators import Contract
from app.intelligence.health_check import score
from app.policy.access_policy import CAPABILITIES, CapabilityBlocked
from app.shopline import oauth, webhooks
from app.store import MemoryStore, Store

SESSION_TTL_S = 12 * 3600


def issue_session(secret: str, shop_id: str, now: float | None = None) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"s": shop_id, "e": int((now or time.time()) + SESSION_TTL_S)}).encode()).decode()
    sig = hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{sig}"


def read_session(secret: str, token: str) -> str | None:
    try:
        body, sig = token.rsplit(".", 1)
        if not hmac.compare_digest(hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest(), sig):
            return None
        d = json.loads(base64.urlsafe_b64decode(body))
        return d["s"] if d["e"] > time.time() else None
    except Exception:
        return None


def create_app(settings: Settings | None = None, store: Store | None = None,
               gateway: Gateway | None = None, http: httpx.Client | None = None) -> FastAPI:
    s = settings or Settings.from_env()
    assert_isolated(s)                       # refuses to boot in prod if not isolated
    st = store or MemoryStore()
    client = http or httpx.Client()
    gw = gateway or Gateway(OpenAICompatAdapter({"nvidia": s.nvidia_api_key, "groq": s.groq_api_key,
                                                 "openrouter": s.openrouter_api_key}), st)
    session_secret = hashlib.sha256(("session:" + s.token_encryption_key).encode()).hexdigest()
    app = FastAPI(title="MAA × SHOPLINE backend", docs_url=None if s.env == "prod" else "/docs")

    @app.exception_handler(Exception)
    async def _unhandled(_req: Request, _exc: Exception):
        return JSONResponse({"state": "error", "reason": "server"}, status_code=500)

    def shop(authorization: str = Header(default="")) -> str:
        shop_id = read_session(session_secret, authorization.removeprefix("Bearer ").strip())
        if not shop_id:
            raise HTTPException(401, "unauthenticated")
        return shop_id

    @app.get("/auth/shopline/start")
    def start(handle: str):
        try:
            return RedirectResponse(oauth.authorize_url(s, st, handle), status_code=302)
        except oauth.OAuthError:
            raise HTTPException(400, "invalid_handle")

    @app.get("/auth/shopline/callback")
    def callback(request: Request):
        try:
            shop_id = oauth.handle_callback(s, st, dict(request.query_params), client)
        except oauth.OAuthError:
            raise HTTPException(400, "authorization_failed")
        # Hand the session to the iOS app via its registered universal link, fragment only.
        return {"session": issue_session(session_secret, shop_id)}

    @app.post("/webhooks/shopline")
    async def hook(request: Request):
        raw = await request.body()
        res = webhooks.receive(st, s.shopline_app_secret, dict(request.headers), raw)
        return JSONResponse({"ok": res.status == 200}, status_code=res.status)

    @app.get("/api/connection")
    def connection(shop_id: str = Depends(shop)):
        inst = next((i for i in getattr(st, "installs", {}).values() if i["shop_id"] == shop_id), None)
        if not inst:
            return {"state": "disconnected"}
        return {"state": {"active": "connected", "token_expired": "token_expired"}.get(inst["status"], "disconnected"),
                "scopes": inst.get("scopes", []),
                "capabilities": {k: c.status.value for k, c in CAPABILITIES.items()}}

    @app.get("/api/health-check")
    def health_check(shop_id: str = Depends(shop)):
        # Orders read is UNCONFIRMED (TD-01): no SHOPLINE read happens; dimensions are unscored.
        try:
            from app.policy.access_policy import require
            require("orders_read", allow_public_doc=False)
            orders = []  # replaced by snapshot repository once TD-01 confirms the surface
        except CapabilityBlocked:
            orders = None
        return {"state": "degraded" if orders is None else "live",
                "result": score(orders, customers_scope=False, today=date.today())}

    @app.post("/api/advisor")
    def advisor(payload: dict, shop_id: str = Depends(shop)):
        q = str(payload.get("question", ""))[:2000]
        if not q.strip():
            raise HTTPException(422, "empty_question")
        out = gw.generate("advisor_answer", Contract(language="ar" if payload.get("lang") == "ar" else "en"),
                          {"facts": {}, "instruction": f"Merchant question: {q}"},
                          Policy(DataClass.MERCHANT_CONFIDENTIAL, shop_id, safety_required=True))
        return {"state": out.state, "answer": out.value, "generated_at": out.generated_at,
                "job_id": out.job_id, "reason": out.reason}

    return app
