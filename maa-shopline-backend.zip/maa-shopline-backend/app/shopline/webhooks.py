"""Webhook pipeline: verify HMAC → authenticate shop → authorize topic →
deduplicate → acknowledge → process → persist → reconcile.

SHOPLINE requires 200 within 5 s and may deliver duplicates; X-Shopline-Webhook-Id
is stable across retries and is the idempotency key.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from app.shopline.oauth import valid_handle
from app.shopline.signing import verify_webhook
from app.store import Store

# Topics we subscribe to. Only the lifecycle topic is actionable until TD-06
# confirms the order/customer/product topic list.
ALLOWED_TOPICS = {"apps/uninstalled", "orders/create", "orders/update", "customers/create",
                  "customers/update", "products/update"}


@dataclass
class WebhookResult:
    status: int
    outcome: str  # rejected_signature | rejected_shop | ignored_topic | duplicate | accepted


def receive(store: Store, secret: str, headers: dict[str, str], raw: bytes) -> WebhookResult:
    h = {k.lower(): v for k, v in headers.items()}
    body_hash = hashlib.sha256(raw).hexdigest()
    if not verify_webhook(raw, h.get("x-shopline-hmac-sha256"), secret):
        store.audit("webhook_bad_signature", {"body_sha256": body_hash})
        return WebhookResult(401, "rejected_signature")
    domain = h.get("x-shopline-shop-domain", "")
    handle = domain.split(".")[0] if domain.endswith(".myshopline.com") else ""
    inst = store.get_installation(handle) if valid_handle(handle) else None
    if not inst:
        store.audit("webhook_unknown_shop", {"domain": domain[:128]})
        return WebhookResult(200, "rejected_shop")  # ack so SHOPLINE stops retrying; nothing persisted
    topic = h.get("x-shopline-topic", "")
    if topic not in ALLOWED_TOPICS:
        return WebhookResult(200, "ignored_topic")
    wid = h.get("x-shopline-webhook-id") or body_hash
    fresh = store.insert_webhook_event(wid, {"shop_id": inst["shop_id"], "topic": topic,
                                             "body_sha256": body_hash, "status": "received"})
    if not fresh:
        return WebhookResult(200, "duplicate")
    # Processing is enqueued, never done inline (5 s deadline). Payload is untrusted data.
    try:
        payload = json.loads(raw or b"{}")
    except ValueError:
        store.audit("webhook_bad_json", {"webhook_id": wid})
        return WebhookResult(200, "accepted")
    if topic == "apps/uninstalled":
        store.mark_uninstalled(handle)
        store.audit("uninstalled", {"shop_id": inst["shop_id"]})
    else:
        store.enqueue({"kind": "sync", "shop_id": inst["shop_id"], "topic": topic,
                       "object_id": str(payload.get("id", ""))[:64]})
    return WebhookResult(200, "accepted")
