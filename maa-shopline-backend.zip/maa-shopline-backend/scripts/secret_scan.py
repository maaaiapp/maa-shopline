#!/usr/bin/env python3
"""Fail if provider/SHOPLINE credentials appear in tracked files."""
import pathlib, re, sys
PATTERNS = {"nvidia": r"nvapi-[A-Za-z0-9_-]{20,}", "groq": r"gsk_[A-Za-z0-9]{20,}",
            "openrouter": r"sk-or-v1-[a-f0-9]{32,}", "hex40_secret": r"(?i)(app[_ ]?secret|app[_ ]?key)\W{0,4}[0-9a-f]{40}"}
SKIP = {".git", ".venv", "__pycache__", ".pytest_cache"}
hits = []
for p in pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").rglob("*"):
    if p.is_file() and not SKIP & set(p.parts):
        t = p.read_text(errors="ignore")
        hits += [f"{p}: {n}" for n, rx in PATTERNS.items() if re.search(rx, t)]
print("\n".join(hits) or "secret scan passed"); sys.exit(1 if hits else 0)
