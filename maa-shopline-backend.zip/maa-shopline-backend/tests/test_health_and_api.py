import os, subprocess, sys, time
from datetime import date, timedelta
import pytest
from fastapi.testclient import TestClient
from app.config import IsolationError, Settings, assert_isolated
from app.intelligence.health_check import score
from app.main import create_app, issue_session, read_session

T = date(2026, 9, 27)

def orders(n_prev, n_cur, repeat_cur=0):
    rows = [{"customer_id": f"p{i}", "created": T - timedelta(days=100 + i % 70), "total": 100.0} for i in range(n_prev)]
    rows += [{"customer_id": f"c{i}", "created": T - timedelta(days=1 + i % 80), "total": 120.0} for i in range(n_cur)]
    rows += [{"customer_id": "c0", "created": T - timedelta(days=2), "total": 120.0}] * repeat_cur
    return rows

def test_missing_scope_is_unscored_never_estimated():
    r = score(None, False, T)
    assert r["overall"] is None and all(d["state"] == "unscored" for d in r["dimensions"])
    assert r["dimensions"][0]["needs"] == "orders_read"

def test_insufficient_history_path():
    r = score(orders(0, 10), True, T)
    assert r["overall"] is None and r["dimensions"][0]["state"] == "insufficient"

def test_scored_is_deterministic_and_evidenced():
    o = orders(40, 60, repeat_cur=3)
    a, b = score(o, True, T), score(o, True, T)
    assert a == b and a["overall"] is not None and a["coverage"] == "3 of 5"
    acq = a["dimensions"][0]
    assert acq["inputs"]["new_customers"] == 60 and acq["score"] == 75   # 60 vs 40 new customers = +50% → 50+25
    assert {d["key"]: d["state"] for d in a["dimensions"]}["market_position"] == "unscored"

def test_all_healthy_is_maintenance_not_invented_weakness():
    r = score(orders(40, 60, repeat_cur=3), True, T)
    if all(d["score"] >= 50 for d in r["dimensions"] if d["state"] == "scored"):
        assert r["maintenance"] and r["binding_constraint"] is None

def test_isolation_assertion(settings):
    assert_isolated(settings)  # test env: no raise
    bad = Settings(**{**settings.__dict__, "env": "prod", "supabase_url": "https://" + "z" * 20 + ".supabase.co"})
    with pytest.raises(IsolationError): assert_isolated(bad)
    with pytest.raises(IsolationError): assert_isolated(Settings(**{**settings.__dict__, "env": "prod", "supabase_ref": ""}))
    with pytest.raises(IsolationError): assert_isolated(Settings(**{**settings.__dict__, "env": "prod", "extra_endpoints": ["https://maa-os.example.com/rpc"]}))
    ok = Settings(**{**settings.__dict__, "env": "prod", "supabase_url": f"https://{'a'*20}.supabase.co", "extra_endpoints": ["https://api.groq.com/x"]})
    assert_isolated(ok)

def test_session_tamper_and_expiry():
    tok = issue_session("k", "shop_1")
    assert read_session("k", tok) == "shop_1"
    assert read_session("other", tok) is None
    assert read_session("k", tok[:-1] + ("0" if tok[-1] != "0" else "1")) is None
    assert read_session("k", issue_session("k", "shop_1", now=time.time() - 13 * 3600)) is None

def test_api_auth_required_and_tenant_from_session(settings):
    c = TestClient(create_app(settings))
    for m, p in [("get", "/api/health-check"), ("get", "/api/connection"), ("post", "/api/advisor")]:
        assert getattr(c, m)(p).status_code == 401
    r = c.get("/api/health-check", headers={"Authorization": "Bearer garbage"})
    assert r.status_code == 401

def test_api_degraded_states_not_errors(settings):
    import hashlib
    app = create_app(settings); c = TestClient(app)
    secret = hashlib.sha256(("session:" + settings.token_encryption_key).encode()).hexdigest()
    h = {"Authorization": "Bearer " + issue_session(secret, "shop_1")}
    hc = c.get("/api/health-check", headers=h).json()
    assert hc["state"] == "degraded" and hc["result"]["overall"] is None
    adv = c.post("/api/advisor", json={"question": "Why is retention down?"}, headers=h).json()
    assert adv["state"] in {"queued", "last_valid", "not_computed", "live"} and "Traceback" not in str(adv)
    assert c.get("/auth/shopline/start", params={"handle": "evil.com/x"}, follow_redirects=False).status_code == 400
    loc = c.get("/auth/shopline/start", params={"handle": "shop1"}, follow_redirects=False).headers["location"]
    assert loc.startswith("https://shop1.myshopline.com/admin/oauth-web/")

def test_isolation_check_script(tmp_path):
    env = {**os.environ, "SHOPLINE_SUPABASE_REF": "a" * 20, "FORBIDDEN_IDENTIFIERS": "maa-main-prod"}
    (tmp_path / "ok.py").write_text(f"URL='https://{'a'*20}.supabase.co'")
    assert subprocess.run([sys.executable, "scripts/isolation_check.py", str(tmp_path)], env=env).returncode == 0
    (tmp_path / "bad.py").write_text(f"URL='https://{'b'*20}.supabase.co'  # maa-main-prod")
    assert subprocess.run([sys.executable, "scripts/isolation_check.py", str(tmp_path)], env=env, capture_output=True).returncode == 1
